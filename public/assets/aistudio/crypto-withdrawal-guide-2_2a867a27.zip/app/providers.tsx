"use client"

import type { ReactNode } from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { WagmiProvider } from "wagmi"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { TonConnectUIProvider } from "@tonconnect/ui-react"
import { wagmiConfig } from "@/lib/wagmi"

const TonAvailableContext = createContext(false)

export function useTonAvailable() {
  return useContext(TonAvailableContext)
}

export function Providers({ children }: { children: ReactNode }) {
  const [queryClient] = useState(() => new QueryClient())
  const [manifestUrl, setManifestUrl] = useState<string | undefined>(undefined)
  // null = still checking, true = manifest reachable, false = unavailable
  const [tonReady, setTonReady] = useState<boolean | null>(null)

  useEffect(() => {
    let cancelled = false
    const url = `${window.location.origin}/tonconnect-manifest.json`

    // TON Connect wallets fetch this manifest from their own servers. On gated
    // preview domains (e.g. *.v0.build) that request is redirected to an auth
    // page instead of returning JSON, which makes the SDK throw a recurring
    // "Manifest content error" while trying to restore a session. To avoid that
    // entirely we only mount TonConnectUIProvider once we confirm the manifest
    // is fetchable as JSON from this exact origin.
    async function checkManifest() {
      try {
        const res = await fetch(url, { cache: "no-store", redirect: "manual" })
        const contentType = res.headers.get("content-type") ?? ""
        if (!cancelled && res.ok && contentType.includes("application/json")) {
          await res.json()
          if (!cancelled) {
            setManifestUrl(url)
            setTonReady(true)
            return
          }
        }
      } catch {
        // ignore – treated as unavailable below
      }
      if (!cancelled) setTonReady(false)
    }

    checkManifest()
    return () => {
      cancelled = true
    }
  }, [])

  // Wait until the manifest check resolves so the provider tree is stable.
  if (tonReady === null) return null

  const inner = (
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
    </WagmiProvider>
  )

  return (
    <TonAvailableContext.Provider value={tonReady}>
      {tonReady && manifestUrl ? (
        <TonConnectUIProvider manifestUrl={manifestUrl}>{inner}</TonConnectUIProvider>
      ) : (
        inner
      )}
    </TonAvailableContext.Provider>
  )
}
