import { DashboardView } from "@/components/dashboard-view"

export default function DashboardPage() {
  return (
    <main className="min-h-dvh bg-background">
      <DashboardView />
    </main>
  )
}
