import { LoginPanel } from "@/components/login-panel"

export default function LoginPage() {
  return (
    <main className="flex min-h-dvh items-center justify-center bg-background px-4 py-10">
      <LoginPanel />
    </main>
  )
}
