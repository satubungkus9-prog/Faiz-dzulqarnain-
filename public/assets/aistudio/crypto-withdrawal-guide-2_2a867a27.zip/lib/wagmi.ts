import { createConfig, http } from "wagmi"
import { mainnet, polygon, arbitrum, optimism, base } from "wagmi/chains"
import { injected, coinbaseWallet, walletConnect } from "wagmi/connectors"

const projectId = process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID ?? ""

export const wagmiConfig = createConfig({
  chains: [mainnet, polygon, arbitrum, optimism, base],
  connectors: [
    injected({ shimDisconnect: true }),
    coinbaseWallet({ appName: "Wallet Login" }),
    ...(projectId
      ? [
          walletConnect({
            projectId,
            showQrModal: true,
            metadata: {
              name: "Wallet Login",
              description: "Login dengan dompet crypto",
              url: "https://example.com",
              icons: [],
            },
          }),
        ]
      : []),
  ],
  transports: {
    [mainnet.id]: http(),
    [polygon.id]: http(),
    [arbitrum.id]: http(),
    [optimism.id]: http(),
    [base.id]: http(),
  },
  ssr: true,
})

export const hasWalletConnect = Boolean(projectId)

declare module "wagmi" {
  interface Register {
    config: typeof wagmiConfig
  }
}
