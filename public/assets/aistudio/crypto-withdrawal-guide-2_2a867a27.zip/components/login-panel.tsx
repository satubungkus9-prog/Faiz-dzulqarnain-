"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAccount, useConnect } from "wagmi"
import { useTonConnectUI, useTonAddress } from "@tonconnect/ui-react"
import { hasWalletConnect } from "@/lib/wagmi"
import { MetaMaskIcon, CoinbaseIcon, WalletConnectIcon, TonIcon } from "@/components/wallet-icons"

export function LoginPanel() {
  const router = useRouter()
  const { isConnected } = useAccount()
  const { connectors, connect, isPending, variables } = useConnect()
  const [tonConnectUI] = useTonConnectUI()
  const tonAddress = useTonAddress()

  useEffect(() => {
    if (isConnected || tonAddress) {
      router.push("/dashboard")
    }
  }, [isConnected, tonAddress, router])

  const metaMask = connectors.find((c) => c.id === "injected" || c.type === "injected")
  const coinbase = connectors.find((c) => c.id === "coinbaseWalletSDK" || c.name.toLowerCase().includes("coinbase"))
  const walletConnect = connectors.find((c) => c.id === "walletConnect")

  const pendingId = isPending ? (variables?.connector as { id?: string } | undefined)?.id : undefined

  return (
    <div className="w-full max-w-sm">
      <div className="rounded-2xl border border-border bg-card p-6 shadow-xl">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
            <svg viewBox="0 0 24 24" className="h-7 w-7 text-primary" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <rect x="2" y="5" width="20" height="14" rx="3" />
              <path d="M16 12h.01M2 9h20" />
            </svg>
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-foreground">Masuk dengan Dompet</h1>
          <p className="mt-1 text-sm text-muted-foreground">Pilih dompet untuk melanjutkan</p>
        </div>

        <div className="flex flex-col gap-3">
          {metaMask && (
            <WalletButton
              label="MetaMask"
              sublabel="Browser extension"
              icon={<MetaMaskIcon className="h-8 w-8" />}
              loading={pendingId === metaMask.id}
              onClick={() => connect({ connector: metaMask })}
            />
          )}

          <WalletButton
            label="Telegram Wallet"
            sublabel="TON Connect"
            icon={<TonIcon className="h-8 w-8" />}
            onClick={() => tonConnectUI.openModal()}
          />

          {coinbase && (
            <WalletButton
              label="Coinbase Wallet"
              sublabel="Smart Wallet"
              icon={<CoinbaseIcon className="h-8 w-8" />}
              loading={pendingId === coinbase.id}
              onClick={() => connect({ connector: coinbase })}
            />
          )}

          {walletConnect && hasWalletConnect && (
            <WalletButton
              label="WalletConnect"
              sublabel="Scan QR / mobile"
              icon={<WalletConnectIcon className="h-8 w-8" />}
              loading={pendingId === walletConnect.id}
              onClick={() => connect({ connector: walletConnect })}
            />
          )}
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          Dengan masuk, Anda menyetujui koneksi dompet ke aplikasi ini.
        </p>
      </div>
    </div>
  )
}

function WalletButton({
  label,
  sublabel,
  icon,
  loading,
  onClick,
}: {
  label: string
  sublabel: string
  icon: React.ReactNode
  loading?: boolean
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={loading}
      className="group flex items-center gap-3 rounded-xl border border-border bg-background px-4 py-3 text-left transition-colors hover:border-primary/50 hover:bg-accent disabled:cursor-not-allowed disabled:opacity-60"
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center">{icon}</span>
      <span className="flex flex-col">
        <span className="text-sm font-medium text-foreground">{label}</span>
        <span className="text-xs text-muted-foreground">{sublabel}</span>
      </span>
      <span className="ml-auto text-muted-foreground">
        {loading ? (
          <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" opacity="0.25" />
            <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          </svg>
        ) : (
          <svg className="h-4 w-4 transition-transform group-hover:translate-x-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path d="m9 18 6-6-6-6" />
          </svg>
        )}
      </span>
    </button>
  )
}
