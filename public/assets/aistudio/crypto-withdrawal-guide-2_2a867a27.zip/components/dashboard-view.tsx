"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAccount, useBalance, useChainId, useDisconnect } from "wagmi"
import { useTonConnectUI, useTonAddress } from "@tonconnect/ui-react"
import { MetaMaskIcon, TonIcon } from "@/components/wallet-icons"

function shorten(addr: string) {
  return addr.length > 12 ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : addr
}

const CHAIN_NAMES: Record<number, string> = {
  1: "Ethereum",
  137: "Polygon",
  42161: "Arbitrum",
  10: "Optimism",
  8453: "Base",
}

export function DashboardView() {
  const router = useRouter()
  const [mounted, setMounted] = useState(false)

  const { address, isConnected } = useAccount()
  const chainId = useChainId()
  const { disconnect } = useDisconnect()
  const { data: balance } = useBalance({ address })

  const [tonConnectUI] = useTonConnectUI()
  const tonAddress = useTonAddress()

  useEffect(() => setMounted(true), [])

  useEffect(() => {
    if (mounted && !isConnected && !tonAddress) {
      router.replace("/")
    }
  }, [mounted, isConnected, tonAddress, router])

  if (!mounted) return null

  const isTon = Boolean(tonAddress)
  const activeAddress = isTon ? tonAddress : address
  const network = isTon ? "TON Network" : CHAIN_NAMES[chainId] ?? "EVM Chain"

  async function handleLogout() {
    if (isConnected) disconnect()
    if (tonAddress) await tonConnectUI.disconnect()
    router.replace("/")
  }

  if (!activeAddress) return null

  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-10">
      <header className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Anda berhasil masuk dengan dompet.</p>
        </div>
        <button
          type="button"
          onClick={handleLogout}
          className="rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
        >
          Keluar
        </button>
      </header>

      <section className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
            {isTon ? <TonIcon className="h-9 w-9" /> : <MetaMaskIcon className="h-9 w-9" />}
          </div>
          <div className="min-w-0">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Dompet terhubung</p>
            <p className="truncate font-mono text-lg font-medium text-foreground">{shorten(activeAddress)}</p>
          </div>
          <span className="ml-auto flex items-center gap-1.5 rounded-full bg-green-500/10 px-3 py-1 text-xs font-medium text-green-500">
            <span className="h-2 w-2 rounded-full bg-green-500" />
            Aktif
          </span>
        </div>
      </section>

      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <StatCard label="Jaringan" value={network} />
        <StatCard
          label="Saldo"
          value={
            isTon
              ? "Lihat di dompet"
              : balance
                ? `${Number(balance.formatted).toFixed(4)} ${balance.symbol}`
                : "—"
          }
        />
      </div>

      <section className="mt-4 rounded-2xl border border-border bg-card p-6 shadow-sm">
        <h2 className="mb-3 text-sm font-medium text-foreground">Alamat lengkap</h2>
        <p className="break-all rounded-lg bg-muted px-3 py-2 font-mono text-sm text-muted-foreground">
          {activeAddress}
        </p>
      </section>
    </div>
  )
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 text-lg font-semibold text-foreground">{value}</p>
    </div>
  )
}
